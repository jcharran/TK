// Initialize function
var init = function() {
  // TODO:: Do your initialization job
  console.log('init() called');
  
  
  
  // Hide the footer of the iframe
  var frameContent = document.getElementById('frame-content');
  var frameDocument = frameContent.contentDocument || frameContent.contentWindow.document;
  var footerElement = frameDocument.querySelector('footer'); // Replace 'footer' with the actual footer element selector
  
  if (footerElement) {
    footerElement.style.display = 'none';
  }
  
 
    
  
};

// Add event listener for 'load' event
window.addEventListener('load', init);



// Event listener for 'visibilitychange' event
document.addEventListener('visibilitychange', function() {
  if (document.hidden) {
    // Something you want to do when hidden or exited
  } else {
    // Something you want to do when resumed
  }
});

// Event listener for 'keydown' event
document.addEventListener('keydown', function(e) {
  switch (e.keyCode) {
    case 37: // LEFT arrow
      break;
    case 38: // UP arrow
      break;
    case 39: // RIGHT arrow
      break;
    case 40: // DOWN arrow
      break;
    case 13: // OK button
      break;
    case 10009: // RETURN button
      tizen.application.getCurrentApplication().exit();
      break;
    default:
      console.log('Key code: ' + e.keyCode);
      break;
  }
});
